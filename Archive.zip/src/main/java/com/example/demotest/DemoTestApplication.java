package com.example.demotest;

import java.io.File;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTestApplication.class, args);
	}
}
class Test
{
    public static void main(String[] args) throws IOException {
        System.out.println("Printing Test Before"+"-"+System.getProperty("operationName"));
        String fileName=args[0];
        File file=new File("./build/classes/test/"+fileName);
        file.createNewFile();
    }

}
